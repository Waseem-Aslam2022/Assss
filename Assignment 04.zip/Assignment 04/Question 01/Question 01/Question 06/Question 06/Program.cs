﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_06
{
      internal class Program
    {
        static void Main(string[] args)
        {
            //*******************Question 06*****************//

            //Initialization of list
            List<int> list = new List<int> { 99,34,67,32,12,45,43,22,11,87,12,};

            //first convert list into decending order then select top 3 numbers 
            var data = from i in list.OrderByDescending(x => x).Take(3)
                       select i;

            Console.WriteLine("**********************************");
            Console.WriteLine("The Top 3 Numbers are Given Below:");
            Console.WriteLine("**********************************");

            //foreach loop to print the desired output
            foreach (var result in data)
            {
                Console.WriteLine("{0}",result);
            }
            Console.WriteLine("*******************");
        }
    }
}
