﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_05
{
    class GroceryItem
    {
         public int Amount { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
             List<GroceryItem> item = new List<GroceryItem>()
            {
                new GroceryItem() { Amount = 5 },
                new GroceryItem() { Amount = 1 },
                new GroceryItem() { Amount = 9 },
                new GroceryItem() { Amount = 2 },
                new GroceryItem() { Amount = 3 },
                new GroceryItem() { Amount = 7 },
                new GroceryItem() { Amount = 4 },
                new GroceryItem() { Amount = 5 },
                new GroceryItem() { Amount = 6 },
                new GroceryItem() { Amount = 8 },
                new GroceryItem() { Amount = 7 },
                new GroceryItem() { Amount = 6 },
                new GroceryItem() { Amount = 3 },
                new GroceryItem() { Amount = 4 },
                new GroceryItem() { Amount = 5 },
                new GroceryItem() { Amount = 2 }

            };

            var query = from r in item
                        group r by r.Amount into g
                        select new { Count = g.Count(), Value = g.Key };
            Console.WriteLine("*****************************************");
            Console.WriteLine("Amount    Qty                   Total ");
            foreach (var v in query)
            {
                Console.WriteLine("{0}          {1}                     {2}", v.Value,  v.Count, v.Value * v.Count);
            }
            Console.WriteLine("*****************************************");

        }
    }
}
