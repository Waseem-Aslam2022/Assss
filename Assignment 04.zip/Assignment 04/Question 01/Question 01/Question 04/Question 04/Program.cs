﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //****************************Question 04***********************************//

            //declare string variable
            string anyString;

            Console.WriteLine("Display the characters and Frequency of Character from giving String : ");
            Console.WriteLine("----------------------------------------------------------------------------");
            Console.WriteLine(" Please Input Your String : "); //take input string
            anyString = Console.ReadLine();
            Console.Write("\n");

            //Find frequency and select it
            var frequency = from x in anyString
                       group x by x into y
                       select y;
            Console.Write("Frequency And Characters are given below :\n");
            Console.WriteLine("******************************************");

            //print the character and its frequency through foreach loop
            foreach (var myArray in frequency)
            {
                Console.WriteLine("Frequency of   " + myArray.Key + "   is: " + myArray.Count());
            }
            Console.WriteLine("******************************************");

        }
    }
}
