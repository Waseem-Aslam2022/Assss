﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_07
{
    public class Student
    {
        //****************Question 01*************
        //declaration
        public int StudentMarks { get; set; }
        public string StudentName { get; set; }
        public int StudentID { get; set; }


    }
    internal class Program
    {
        static void Main(string[] args)
        {
            IList<Student> studentList = new List<Student>()
            {
                 new Student() { StudentID = 1, StudentName = "Waseem",       StudentMarks =  40},
                 new Student() { StudentID = 2, StudentName = "Fareed",       StudentMarks =  30},
                 new Student() { StudentID = 3, StudentName = "Nouman",       StudentMarks =  50},
                 new Student() { StudentID = 4, StudentName = "Ali   ",       StudentMarks =  35},
                 new Student() { StudentID = 5, StudentName = "Ahmad ",       StudentMarks =  67},
                 new Student() { StudentID = 6, StudentName = "Hussain",      StudentMarks =  78},
                 new Student() { StudentID = 7, StudentName = "Akbar ",       StudentMarks =  88},
                 new Student() { StudentID = 8, StudentName = "Imran ",       StudentMarks =  99},
                 new Student() { StudentID = 9, StudentName = "Zeeshan",      StudentMarks =  78},
                 new Student() { StudentID = 10,StudentName = "Hamail",       StudentMarks =  87}
            };
            var result1 = studentList.Where(a => a.StudentID!= 1).Where(a => a.StudentID !=2);
            Console.WriteLine("Lambda Query");
             foreach (var id in result1)
            {
                Console.WriteLine("Student ID : " + id.StudentID + " Student Name : " + id.StudentName + "Student Marks : " + id.StudentMarks);
            }
        }
    }
}
