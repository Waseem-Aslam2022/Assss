﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_02
{
    internal class Program
    {
        class Student
        {
            //*************** Question 02*****************

            // Declare variable name
            string name;
            // Get the to string method that returns name
            public override string ToString()
            {
                return name;
            }
            static void Main(string[] args)
            {
                // Declare a list variable 
                List<Student> student = new List<Student>()
                {
                    // Creation of Student details
                    new Student{ name = "Mohsin"},
                    new Student{ name = "Bilal"},
                    new Student{ name = "muhammad Arshad"},
                    new Student{ name = "Fareed Ahmad"},
                    new Student{ name = "Nouman Khan"},
                    new Student{ name = "Maaz Ali"},
                    new Student{ name = "Muhabbat Khan"}

                };
                // Iterate the Student by selecting Student 
                // name starts with 
                // Using Where() function
                IEnumerable<Student> Query = student.Where(s => s.name[0] == 'M');
                // Display employee details
                Console.WriteLine("Student Name Start With M Alphabet:");
                Console.WriteLine("****************");
                foreach (Student e in Query)
                {

                    // Call the to string method
                    Console.WriteLine(e.ToString());
                    Console.WriteLine("****************");

                }

            }
        }
    }
}
