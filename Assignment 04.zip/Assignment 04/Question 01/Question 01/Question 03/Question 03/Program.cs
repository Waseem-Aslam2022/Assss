﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
                //**************Question 03********************//


               //Array declaration of 10 numbers
              int[] numbers = new int[10] { 1,10,11,18, 2, 3,22, 4, 5, 6 };

            //  Query creation.
            // numQuery is an IEnumerable<int>
            var numQuery = from number in numbers
                           //number is even if it gives remainder 0 on divided by 2
                           where (number % 2) == 0
                           orderby number ascending
                           select number;

            // Query execution to print array
            foreach (int number in numQuery)
            {
                Console.WriteLine("{0,1} ", number);
            }
        }
    }
}
