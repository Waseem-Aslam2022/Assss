﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_01
{
    public class Student
    {
        //****************Question 01*************
        //declaration
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }

    }
    internal class Program
    {

        static void Main(string[] args)
        {
            // Student collection
            IList<Student> studentList = new List<Student>()
                {
                    new Student() { StudentID = 1, StudentName = "Waseem",       Age = 13} ,
                    new Student() { StudentID = 2, StudentName = "Fareed",       Age = 25 } ,
                    new Student() { StudentID = 3, StudentName = "Nouman",       Age = 18 } ,
                    new Student() { StudentID = 4, StudentName = "Ali Akbar" ,   Age = 30} ,
                    new Student() { StudentID = 5, StudentName = "Ahmad Hussain",Age = 15 },
                    new Student() { StudentID = 5, StudentName = "Haseeb Zahid", Age = 13 }

                };
            

            // LINQ Query Syntax to find out teenager students
            var teenAgerStudent = from s in studentList
                                  where s.Age > 12 && s.Age < 20
                                  select s;
            Console.WriteLine("The Teenage Students are given as:");
            Console.WriteLine("************************************");

            foreach (Student std in teenAgerStudent) //loop to print teenagestudent 
            {
                Console.WriteLine(std.StudentName);
            }
            Console.WriteLine("************************************");

        }

    }
}
       

